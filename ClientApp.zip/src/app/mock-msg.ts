import { AngularTempDataModel } from './AngularTempDataModel';


export const MESSAGES: AngularTempDataModel[] = [
  { id: 1, tempA: '', tempB: '' },
  { id: 2, tempA: '', tempB: '' },
];
