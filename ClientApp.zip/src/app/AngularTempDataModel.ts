export class AngularTempDataModel {
    id: number;
    tempA: string;
    tempB: string;
 }
